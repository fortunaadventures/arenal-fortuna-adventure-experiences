ARENAL FORTUNA ADVENTURE EXPERIENCES — WEBSITE STARTER

Files:
- index.html: bilingual responsive website (English/Spanish)
- README.txt: these instructions

Current features:
- Responsive layout for desktop and mobile
- English/Spanish language toggle
- Rafting and ATV sections
- Contact / booking request form that opens WhatsApp with the visitor's details
- WhatsApp contact number: +506 7250 0633
- No paid form backend required for the current WhatsApp-based request form

Important before publishing:
1. Replace the sample photos with images you have permission to use. The current photo links are illustrative external Unsplash images and may not depict the exact tours being sold.
2. Add the real retail prices and exact tour details after confirming net rates, inclusions, age/driver requirements, cancellation terms and availability with each operator.
3. Confirm the legal business/agency disclosures and privacy terms appropriate for your operation.
4. The contact form does not send an email or save submissions to a database. It opens WhatsApp with a prefilled message; the visitor must press Send.
5. Keep the WhatsApp number updated if needed.

Free publishing option:
- Create a GitHub account and a new public repository.
- Upload index.html.
- In repository Settings > Pages, publish from the main branch/root if GitHub Pages is available for your account and repository settings.
- Alternatively, use Cloudflare Pages and connect the GitHub repository.
- The site can use a free platform subdomain; a custom .com domain is usually paid.

To edit text/prices:
- Open index.html in a text editor.
- Search for "Price on request" and replace with verified prices when ready.
- Search for the tour descriptions and update them to match the partner operators' actual services.


IMPORTANT PRICING NOTE:
The draft now includes public reference prices and descriptions taken from:
- https://outbackquads.com/location/atv-la-fortuna-arenal/
- https://arenalrafting.com/
These are not confirmed reseller/net prices. Before publishing for commercial use, confirm permission to resell, your net rates, applicable taxes, promotions, and retail prices with each operator. The site currently labels prices as references and says to reconfirm.
